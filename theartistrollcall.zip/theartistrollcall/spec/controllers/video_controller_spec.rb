require 'rails_helper'

RSpec.describe VideoController, type: :controller do

end
