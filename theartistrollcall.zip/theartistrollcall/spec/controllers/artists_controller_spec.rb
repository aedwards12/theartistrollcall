require 'rails_helper'

RSpec.describe ArtistsController, type: :controller do

end
