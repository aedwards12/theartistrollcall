require 'rails_helper'

RSpec.describe WelcomeController, type: :controller do

end
